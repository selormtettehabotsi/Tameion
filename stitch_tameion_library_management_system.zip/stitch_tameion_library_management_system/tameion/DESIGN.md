---
name: Tameion
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3f493f'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6f7a6e'
  outline-variant: '#becabc'
  surface-tint: '#006d30'
  primary: '#00652c'
  on-primary: '#ffffff'
  primary-container: '#15803d'
  on-primary-container: '#d3ffd5'
  inverse-primary: '#79db8d'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#146433'
  on-tertiary: '#ffffff'
  tertiary-container: '#337d49'
  on-tertiary-container: '#d0ffd5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#95f8a7'
  primary-fixed-dim: '#79db8d'
  on-primary-fixed: '#00210a'
  on-primary-fixed-variant: '#005323'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#a6f4b5'
  tertiary-fixed-dim: '#8bd79b'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#005226'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is engineered for high-utility academic environments, prioritizing efficiency, clarity, and institutional trust. It balances the rigor of an educational authority with the streamlined performance of a modern automated system. 

The aesthetic is **Corporate / Modern**, leaning heavily into functional minimalism to ensure that data-heavy library tasks remain cognitively light. The interface utilizes generous whitespace, crisp structural alignment, and a systematic hierarchy to evoke a sense of professional reliability and technological sophistication.

## Colors
The palette is rooted in a deep "Academic Green" that symbolizes growth and the KNUST identity. 

- **Primary & Tertiary:** Use Green-700 (#15803d) for primary actions and brand elements. Green-800 (#166534) is reserved for hover states and deep-contrast text components to ensure accessibility.
- **Backgrounds:** The primary interface background uses Gray-50 (#f9fafb) to reduce eye strain, while component cards utilize pure White (#ffffff) to create a clear visual lift.
- **Functional Colors:** Blue-600 is employed strictly for informational cues and secondary navigation actions, while Red-600 handles critical errors and destructive actions.
- **Currency:** All financial data (fines, fees) must be prefixed with the **GH₵** symbol, rendered in the primary text color.

## Typography
This design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-dense layouts. 

- **Hierarchy:** Use bold weights for headlines to anchor the page, while body text remains at a 400 weight for optimal reading flow.
- **Data Display:** For ISBN numbers, Call Numbers, and Transaction IDs, use `body-md` to maintain a professional, systematic look.
- **Labels:** Small caps or uppercase transformations are used for table headers and section labels to differentiate them from interactive content.

## Layout & Spacing
The layout follows a **Fluid Grid** model built on an 8px base unit. 

- **Desktop:** A 12-column grid with 24px gutters. Content is typically contained within a maximum width of 1440px to ensure line lengths remain readable.
- **Mobile:** A 4-column grid with 16px margins. Complex tables should transition to card-based layouts or utilize horizontal scrolling with fixed first columns.
- **Rhythm:** Vertical spacing between sections should use `xl` (32px), while spacing between related input fields should use `md` (16px).

## Elevation & Depth
Hierarchy is established through **Tonal Layers** and extremely subtle shadows.

- **Level 0 (Background):** Gray-50.
- **Level 1 (Cards/Surface):** Pure White with a 1px border (#e5e7eb) and a soft ambient shadow (Y: 1px, Blur: 3px, Opacity: 0.05, Color: Black).
- **Level 2 (Overlays/Modals):** Pure White with a more pronounced shadow (Y: 10px, Blur: 20px, Opacity: 0.1) to clearly separate floating actions from the background data.
- **Contrast:** Use high-contrast dividers (#f3f4f6) to separate table rows and list items rather than shadows.

## Shapes
The shape language is structured and "Soft-Geometric."

- **Components:** Standard buttons, input fields, and cards use `rounded-lg` (0.5rem / 8px).
- **Status Pills:** Badges for "Available," "Reserved," or "Overdue" use `rounded-full` (pill shape) to distinguish them from interactive buttons.
- **Interactive States:** Focus rings must always follow the corner radius of the element they surround, maintaining a 2px offset.

## Components
- **Buttons:** Primary buttons use a solid Green-700 fill with white text. Secondary buttons use a white background with a Green-700 border and text. Hover states shift the background to Green-800.
- **Input Fields:** Use a 1px border (#d1d5db). On focus, the border transitions to Green-700 with a 3px soft outer glow (ring) in a translucent Green-700.
- **Tables:** Headers use a Gray-50 background with `label-md` typography. Row borders are 1px solid Gray-100.
- **Status Badges:**
  - *Success:* Green-100 background with Green-800 text.
  - *Warning:* Yellow-100 background with Yellow-800 text.
  - *Error:* Red-100 background with Red-800 text.
- **Icons:** Use thin-stroke (1.5px or 2px) line-art SVGs. Icons must be monochrome, adopting the color of the text they accompany.
- **Cards:** White background, `rounded-lg` corners, and the subtle Level 1 shadow.